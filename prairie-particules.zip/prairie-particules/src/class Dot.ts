export class Dot {
    x: number;  // x-coordinate of the dot
    y: number;  // y-coordinate of the dot
    dx: number;  // speed in the x-direction
    dy: number;  // speed in the y-direction
    radius: number;  // radius of the dot
    color: string;  // color of the dot
    spawnX: number;  // x-coordinate of the dot's spawn point
    spawnY: number;  // y-coordinate of the dot's spawn point

    constructor(x: number, y: number, dx: number, dy: number) {
        // Initialize the dot with given values
        this.x = x;
        this.y = y;
        this.dx = dx;
        this.dy = dy;
        this.radius = Math.floor(Math.random() * 50);  // Set a random radius
        this.color = this.generateRandomColor();  // Set a random color
        this.spawnX = x;  // Set the spawn point's x-coordinate
        this.spawnY = y;  // Set the spawn point's y-coordinate
    }

    draw(ctx: CanvasRenderingContext2D) {
        // Calculate distance from spawn point using Pythagorean theorem
        const distanceToSpawn = Math.sqrt((this.x - this.spawnX) ** 2 + (this.y - this.spawnY) ** 2);
        
        // Calculate a new radius, reducing based on distance from spawn point
        const radius = Math.max(1, this.radius - distanceToSpawn / 10);
        
        // Calculate gradient intensity based on the distance
        const gradientIntensity = this.calculateGradientIntensity(distanceToSpawn);
        
        // Create a radial gradient with inner and outer.
        const gradient = ctx.createRadialGradient(this.x, this.y, 1, this.x, this.y, radius);
        
        gradient.addColorStop(0, this.color);  // Set the dot color
        gradient.addColorStop(1, `rgba(255, 255, 255, ${gradientIntensity})`);  // Set the gradient's transparency
        
        ctx.fillStyle = gradient;  // Set the fill style to the gradient
        ctx.beginPath();  // Start drawing a path
        ctx.arc(this.x, this.y, radius, 0, Math.PI * 2);  // Draw a circle
        ctx.fill();  // Fill the circle with the gradient

    }

    drawTrail(ctx: CanvasRenderingContext2D, trailLength: number) {
        // Set trail opacity
        const trailOpacity = 0.08;
        
        // Calculate trail end coordinates
        const trailEndX = this.x - this.dx * trailLength;
        const trailEndY = this.y - this.dy * trailLength;
    
        ctx.strokeStyle = `rgba(255, 255, 255, ${trailOpacity})`;  // Set trail color and opacity
        ctx.lineWidth = this.radius/8;  // Set trail line width
        ctx.beginPath();  // Start drawing a path
        ctx.moveTo(this.x, this.y);  // Move to the dot's current position
        ctx.lineTo(trailEndX, trailEndY);  // Draw a line to the trail's end
        ctx.stroke();  // Draw the trail
    }
    
    update() {
        // Update the dot's position based on its speed
        this.x += this.dx;
        this.y += this.dy;
    }

    generateRandomColor(): string {
        // Generate a random RGB color
        const r = Math.floor(Math.random() * 256);
        const g = Math.floor(Math.random() * 256);
        const b = Math.floor(Math.random() * 256);
        return `rgb(${r},${g},${b})`;  // Return the RGB color as a string
    }

    // Calculate gradient intensity based on the distance
    calculateGradientIntensity(distance: number): number {
        const maxDistance = 100;  // Set the maximum distance for gradient intensity
        return Math.min(1, 1 - distance / maxDistance);  // Calculate and return the gradient intensity
    }
}