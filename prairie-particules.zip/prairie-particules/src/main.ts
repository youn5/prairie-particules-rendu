import "./style.css";
import { Dot } from "./class Dot";

const canvas = document.querySelector<HTMLCanvasElement>("#particules-canvas")!;
const ctx = canvas.getContext("2d")!;
const width = (canvas.width = window.innerWidth);
const height = (canvas.height = window.innerHeight);

const maxDotsInCluster = 100;
const clusterRadius = 40;

const context = new AudioContext();
const masterVolume = context.createGain();

canvas.style.background = "#000000";
// Connect the master volume to the final audio destination.
masterVolume.connect(context.destination);

// Set the gain (volume) of the master volume to 0.1 at the starting time (0 seconds).
masterVolume.gain.setValueAtTime(0.1, 0);

let dots: Dot[] = [];

function createCluster(x: number, y: number) {
    const numberOfDots = Math.random() * maxDotsInCluster;
    for (let i = 0; i < numberOfDots; i++) {
        const angle = Math.random() * Math.PI * 2;
        const distance = Math.random() * clusterRadius;
        const dx = (Math.cos(angle) * distance) ;
        const dy = (Math.sin(angle) * distance) ;
        dots.push(new Dot(x, y, dx, dy));
    }

    // Declare a variable named 'oscillator' that can hold either an OscillatorNode or be empty (null).
    let oscillator: OscillatorNode | null = null;

    // Calculating the frequency based on the number of dots in the cluster
    // to change the sound based on the number of points.
    const frequency = 1500 - numberOfDots * 10;

    // Creating an oscillator in the audio context.
    oscillator = context.createOscillator();

    // Setting the frequency of the oscillator.
    oscillator.frequency.setValueAtTime(frequency, 0);

    // Connecting the oscillator to the master volume.
    oscillator.connect(masterVolume);

    // Starting the oscillator to produce sound.
    oscillator.start(0);

    // Stopping the oscillator after 0.1 seconds to limit the sound duration.
    oscillator.stop(context.currentTime + 0.1);

}

function updateAndDrawParticles() {
    ctx.clearRect(0, 0, width, height);

    for (const dot of dots) {
        dot.update();
        dot.draw(ctx);
        const trailLength = 10;
        dot.drawTrail(ctx, trailLength);
    }

    requestAnimationFrame(updateAndDrawParticles);// fluidify the animation
}

addEventListener('click', (event) => {
    createCluster(event.clientX, event.clientY);
});

updateAndDrawParticles();